<!DOCTYPE html 
     PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
     "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Image Verification</title>
<link href="styles.css" rel="stylesheet" type="text/css" />
</head>
<body>

<h1>Image Verification Example</h1>

<?php

	// The PHP code below demostrates how to determine whether the 
	// request paramter for the verification code field matches the 
	// last security image that was displayed.  Your PHP code must 
	// pass the request parameter value to the isChallengeAccepted() 
	// method, which will return TRUE or FALSE based on whether 
	// the match was successful or not.
	
	// This will be the request parameter name.  When we create the form,  
	// this name will be used for the "name" attribute of the input tag.
	$CHALLENGE_FIELD_PARAM_NAME = "verificationCode"; 
	
	// The following include is required in order to call 
	// the isChallengeAccepted() function.
	require_once('includes/challenge.php');

	// If there was a form post, handle it 
	if(isset($_POST[$CHALLENGE_FIELD_PARAM_NAME])) {

		// Check challenge string
		if(isChallengeAccepted($_POST[$CHALLENGE_FIELD_PARAM_NAME]) === FALSE) {
		    $resultMessage = "The entered verification code was not correct.";
		} else {
			$resultMessage = "Verification code accepted!";
		}
		
	} else {
		
		$resultMessage = "";
		
	}

?>

<p>
This page is intended to demonstrate how you can quickly add  
a challenge response security image to your own PHP scripts.
</p>

<?php

	// If there is a result message from the form post, display it 
	if(!empty($resultMessage)) {
		echo "<p class=\"resultMessage\">{$resultMessage}</p>\n";
	}

	// The HTML below demonstrates how to include the challenge image in 
	// a form.  Modify the "src" attribute to correspond to the path where 
	// the script was installed.

?>

<form method="post" action=".">
<fieldset>
<legend>Challenge Response</legend>
<p>
<label for="subject">Enter Verification Code:</label>
<input type="text" 
	name="<?php echo($CHALLENGE_FIELD_PARAM_NAME) ?>" 
	id="<?php echo($CHALLENGE_FIELD_PARAM_NAME) ?>" 
	maxlength="<?php echo($CHALLENGE_STRING_LENGTH) ?>" 
	size="<?php echo($CHALLENGE_STRING_LENGTH) ?>" 
	class="inputText" />
<img src="getimage.php" />
</p>
<input type="submit" value="Send" class="submit" />
</fieldset>  
</form>

<?php
	// If you find this software useful, a simple link back to our web site 
	// would be extremely appreciated.  The following function will display 
	// our preferred link code.
	the_credits();
?>

</body>
</html>