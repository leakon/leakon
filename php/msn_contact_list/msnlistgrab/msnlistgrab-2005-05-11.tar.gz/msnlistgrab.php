<?php

	/****************************************************************************************
	*                      			 MSN CONTACT LIST GRAB CLASS                            *
	*             (c)2005 Ghulam Mustafa, mustafa.pk@gmail.com, Pakistan                    *
	*                               ver 1.0 (04.02.2005)                                    *
	****************************************************************************************/
	
class msnlistgrab {
	var $user='user name goes here';
	var $password='password goes here' ;
	var $server ='messenger.hotmail.com';
	var $port = 1863;
	var $version = 'MSNMSGR 6.2';
	var $buffer;
	var $socket;
	var $startcom;
	var $error="";
	function msnlistgrab() {

	}
	function GetRecords(){
		if ($this->msn_connect($this->server, $this->port))
		{
			return $this->res;
		}
		else
		{
			return $this->error;
		}
	}

	function getData() {
		$this->buffer="";
		while (!feof($this->socket)) {
			$this->buffer .= fread($this->socket,1024);
			if (preg_match("/\r/",$this->buffer)) {
				break;
			}
		}
		$this->checkData($this->buffer);
	}
	function getData2() {;
	//$container="";
	$buffer="";
	while (!feof($this->socket)) {
		if ($this->i>1) {
			if ($this->i==$this->total) {
				fclose($this->socket);
				$this->res;
				break;
			}
		}
		$buffer = fread($this->socket,8192);
		$this->check_buffer($buffer);
	}
	}

	function check_buffer($buffer) {
		if (eregi("^SYN",$buffer)) {
			list($junk, $junk, $junk, $this->total) = explode(" ", $buffer);
			//	echo '<h1>Number of Records: '.$this->total.'</h1>';
		}
		$this->grabber($buffer);
	}

	function grabber ($buffer)
	{
		$g = preg_split("/[\n]+/", $buffer);
		for ($n=0;$n<count($g);$n++) {
			if (strstr($g[$n], 'LST')) {
				$this->i++;
				//echo $i.',';
				list($junk, $email) = explode(" ", $g[$n]);
				$this->res[] = $email;
			}
		}

	}

	function checkData($buffer) {
		//              echo $buffer;
		if (preg_match("/lc\=(.+?)/Ui",$buffer,$matches)) {

			$this->challenge = "lc=" . $matches[1];

		}

		if (preg_match("/(XFR 3 NS )([0-9\.\:]+?) (.*) ([0-9\.\:]+?)/is",$buffer,$matches)) {
			$split = explode(":",$matches[2]);
			$this->startcom = 1;
			$this->msn_connect($split[0],$split[1]);

		}

		if (preg_match("/tpf\=([a-zA-Z0-9]+?)/Ui",$buffer,$matches)) {

			$this->nexus_connect($matches[1]);
		}
		/*
		$split = explode("\n",$buffer);

		for ($i=0;$i<count($split);$i++) {

		$detail = explode(" ",$split[$i]);

		if ($detail[0] == "LST") {
		//echo "<div  OnMouseOver=\"style.cursor='hand';showTooltip('show','$detail[1]-$detail[3]')\" OnMouseMove=\"followTooltip('show')\" OnMouseOut=\"showTooltip('hide')\">" . urldecode($detail[2]) . "</div>";
		}
		}
		*/



	}

	function msn_connect($server, $port) {

		if (IsSet($this->socket)) {
			fclose($this->socket);
		}

		$this->socket = fsockopen($server,$port);       //stream_set_timeout($GLOBALS["socket"], 20000);
		if (!$this->socket) {
			return "Could not connect";
		} else {
			$this->startcom++;
			$this->send_command("VER " . $this->startcom . " MSNP8 CVR0",1);
			$this->send_command("CVR " . $this->startcom . " 0x0409 win 4.10 i386 ". $this->version ." MSMSGS " . $this->user . "@hotmail.com",1);
			$this->send_command("USR " . $this->startcom . " TWN I " . $this->user . "@hotmail.com",1);

		}
	}

	function send_command($command)
	{
		$this->startcom++;
		//      echo "<font color=blue> >> $command<br>";
		fwrite($this->socket,$command . "\r\n");
		$this->getData();


	}


	function nexus_connect($tpf)
	{

		$arr[] = "GET /rdr/pprdr.asp HTTP/1.0\r\n\r\n";

		$curl = curl_init();
		curl_setopt($curl, CURLOPT_URL, "https://nexus.passport.com:443/rdr/pprdr.asp");
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($curl, CURLOPT_VERBOSE, 0);
		curl_setopt($curl, CURLOPT_HEADER,1);
		curl_setopt($curl, CURLOPT_HTTPHEADER, $arr);
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
		$data = curl_exec($curl);
		curl_close($curl);
		preg_match("/DALogin=(.+?),/",$data,$matches);

		//$data = str_replace("\n","<br>",$data);
		//              echo $data;

		//echo "<br><br>";

		$split = explode("/",$matches[1]);

		$headers[0] = "GET /$split[1] HTTP/1.1\r\n";
		$headers[1] = "Authorization: Passport1.4 OrgVerb=GET,OrgURL=http%3A%2F%2Fmessenger%2Emsn%2Ecom,sign-in=" . $this->user . "%40hotmail.com,pwd=" . $this->password . ", " . trim($this->challenge) . "\r\n";

		$curl = curl_init();
		curl_setopt($curl, CURLOPT_URL, "https://" . $split[0] . ":443/". $split[1]);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($curl, CURLOPT_VERBOSE, 0);
		curl_setopt($curl,CURLOPT_FOLLOWLOCATION,1);
		curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
		curl_setopt($curl, CURLOPT_HEADER,1);
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);

		$data = curl_exec($curl);

		//$data = str_replace("\n","<br>\n",$data);
		//              echo $data;

		curl_close($curl);

		//echo "</font>";

		preg_match("/t=(.+?)'/",$data,$matches);
		$this->send_command("USR " . $this->startcom . " TWN S t=" . trim($matches[1]) . "",2);
		$this->send_command("SYN " . $this->startcom . " 0",2);
		$this->getData2();



	}

}
//end of the file
?>