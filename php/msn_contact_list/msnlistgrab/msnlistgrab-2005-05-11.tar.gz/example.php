<?php
include('msnlistgrab.php');
$gm = new msnlistgrab();
$gm->GetRecords();
foreach ($gm->res as $val)
{
	echo $val .'<BR>';
}
echo '<hr>'.$gm->total;
?>